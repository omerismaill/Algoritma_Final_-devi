﻿// Bu sınıf, programın ana sınıfıdır.
class Program
{
    // Bu, programın başlangıç noktası olan ana metod.
    static void Main()
    {
        // Grafiği temsil etmek için 2B boyutlu bir dizi tanımlanıyor.
        // graph[i, j] değeri, i ve j düğümleri arasındaki kenarın ağırlığını temsil eder.
        int[,] graph = new int[,]
        {
{ 0, 4, 0, 0, 0, 0, 0, 8, 0 },
{ 4, 0, 8, 0, 0, 0, 0, 11, 0 },
{ 0, 8, 0, 7, 0, 4, 0, 0, 2 },
{ 0, 0, 7, 0, 9, 14, 0, 0, 0 },
{ 0, 0, 0, 9, 0, 10, 0, 0, 0 },
{ 0, 0, 4, 14, 10, 0, 2, 0, 0 },
{ 0, 0, 0, 0, 0, 2, 0, 1, 6 },
{ 8, 11, 0, 0, 0, 0, 1, 0, 7 },
{ 0, 0, 2, 0, 0, 0, 6, 7, 0 }
        };

        // Düğümlerin kökünü tutmak için bir dizi tanımlanıyor.
        int[] parent = new int[graph.GetLength(0)];
        // Düğümlerin rank'ini tutmak için bir dizi tanımlanıyor.
        int[] rank = new int[graph.GetLength(0)];

        // Her düğümün başlangıçta kendi kökü ve rank'i 1 olarak ayarlanıyor.
        for (int i = 0; i < parent.Length; i++)
        {
            parent[i] = i;
            rank[i] = 1;
        }

        // Kenarları tutmak için bir liste tanımlanıyor.
        List<Edge> edges = new List<Edge>();

        // Tüm düğümler için döngü yapılıyor.
        for (int i = 0; i < graph.GetLength(0); i++)
        {
            // Tüm düğümler için iç içe döngü yapılıyor.
            for (int j = 0; j < graph.GetLength(1); j++)
            {
                // Eğer i ve j düğümleri arasında bir kenar varsa,
                if (graph[i, j] != 0)
                {
                    // Kenarın bilgileri ile Edge sınıfından yeni bir nesne oluşturularak,
                    // kenarlar listesine ekleniyor.
                    edges.Add(new Edge(i, j, graph[i, j]));
                }
            }
        }

        // Kenarlar listesi sıralanıyor.
        edges.Sort();

        // Minimum çevrimli ağaçın maliyetini tutmak için bir değişken tanımlanıyor.
        int minCost = 0;
        // Kenarların bilgilerini tutmak için bir liste tanımlanıyor.
        List<Edge> mst = new List<Edge>();

        // Tüm kenarlar için döngü yapılıyor.
        foreach (Edge edge in edges)
        {
            // Kenarın başlangıç ve bitiş düğümlerinin kökleri bulunuyor.
            int x = Find(parent, edge.Source);
            int y = Find(parent, edge.Destination);

            // Eğer x ve y kökleri farklıysa,
            if (x != y)
            {
                // Kenarın ağırlığı minimum çevrimli ağaçın maliyetine ekleniyor.
                minCost += edge.Weight;
                // Kenar mst listesine ekleniyor.
                mst.Add(edge);
                // x ve y düğümleri birleştiriliyor.
                Union(parent, rank, x, y);
            }
        }

        // Minimum çevrimli ağaçın kenarları ekrana yazdırılıyor.
        Console.WriteLine("Minimum çevrimli ağaç:");
        foreach (Edge edge in mst)
        {
            Console.WriteLine($"{edge.Source} - {edge.Destination}: {edge.Weight}");
        }

        // Minimum çevrimli ağaçın maliyeti ekrana yazdırılıyor.
        Console.WriteLine($"Toplam maliyet: {minCost}");
    }

    // Düğümün kökünü bulmak için kullanılan yardımcı metod.
    static int Find(int[] parent, int x)
    {
        // Eğer x düğümünün kökü kendisi değilse,
        if (parent[x] != x)
        {
            // x düğümünün kökü bulunur ve parent dizisindeki x değeri,
            // bulunan kök ile güncellenir.
            parent[x] = Find(parent, parent[x]);
        }

        // x düğümünün kökü döndürülür.
        return parent[x];
    }

    // İki düğümü birleştirmek için kullanılan yardımcı metod.
    static void Union(int[] parent, int[] rank, int x, int y)
    {
        // x ve y düğümlerinin kökleri bulunur.
        int rootX = Find(parent, x);
        int rootY = Find(parent, y);

        // Eğer rootX'in rank'i rootY'in rank'inden büyükse,
        if (rank[rootX] > rank[rootY])
        {
            // rootY'in kökü rootX ile güncellenir.
            parent[rootY] = rootX;
        }
        // Eğer rootX'in rank'i rootY'in rank'inden küçükse,
        else if (rank[rootX] < rank[rootY])
        {
            // rootX'in kökü rootY ile güncellenir.
            parent[rootX] = rootY;
        }
        // Eğer rootX'in rank'i rootY'in rank'ine eşitse,
        else
        {
            // rootY'in kökü rootX ile güncellenir ve,
            // rootX'in rank'i 1 artırılır.
            parent[rootY] = rootX;
            rank[rootX]++;
        }
    }

    // Kenar bilgilerini tutmak için kullanılan sınıf.
    class Edge : IComparable<Edge>
    {
        // Kenarın başlangıç düğümü.
        public int Source { get; set; }
        // Kenarın bitiş düğümü.
        public int Destination { get; set; }
        // Kenarın ağırlığı.
        public int Weight { get; set; }

        // Kenar sınıfından yeni bir nesne oluşturulurken,
        // gerekli bilgiler parametre olarak alınır.
        public Edge(int source, int destination, int weight)
        {
            Source = source;
            Destination = destination;
            Weight = weight;
        }

        // İki kenarın ağırlıkları karşılaştırılır.
        public int CompareTo(Edge other)
        {
            return Weight.CompareTo(other.Weight);
        }
    }
}