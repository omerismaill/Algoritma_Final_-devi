﻿using System; // System ad alanını kullan
using System.Collections.Generic; // Collections.Generic ad alanını kullan

class Program // Program sınıfı tanımla
{
    static void Main() // Main metodunu tanımla, bu metod programın giriş noktasıdır
    {
        int[,] graph = new int[,] // graph adlı 2B boyutlu bir diziyi tanımla ve değerlerini ata
        {
            { 0, 4, 0, 0, 0, 0, 0, 8, 0 },
            { 4, 0, 8, 0, 0, 0, 0, 11, 0 },
            { 0, 8, 0, 7, 0, 4, 0, 0, 2 },
            { 0, 0, 7, 0, 9, 14, 0, 0, 0 },
            { 0, 0, 0, 9, 0, 10, 0, 0, 0 },
            { 0, 0, 4, 14, 10, 0, 2, 0, 0 },
            { 0, 0, 0, 0, 0, 2, 0, 1, 6 },
            { 8, 11, 0, 0, 0, 0, 1, 0, 7 },
            { 0, 0, 2, 0, 0, 0, 6, 7, 0 }
        };

        int[] key = new int[graph.GetLength(0)]; // key adlı bir dizi tanımla, boyutunu graph dizisinin boyutuyla eşit olacak şekilde ayarla
        bool[] mstSet = new bool[graph.GetLength(0)]; // mstSet adlı bir bool dizisi tanımla, boyutunu graph dizisinin boyutuyla eşit olacak şekilde ayarla

        for (int i = 0; i < key.Length; i++) // key dizisinin boyutu kadar döngü
        {
            key[i] = int.MaxValue; // key dizisinin i. indisli değerini int.MaxValue değerine eşitler
            mstSet[i] = false; // mstSet dizisinin i. indisli değerini false değerine eşitler
        }

        key[0] = 0; // key dizisinin 0. indisli değerini 0 değerine eşitler
        int minCost = 0; // minCost adlı bir değişken tanımla ve değerini 0 olarak ayarla

        for (int i = 0; i < graph.GetLength(0) - 1; i++) // graph dizisinin boyutu - 1 kadar döngü
        {
            int minKey = int.MaxValue; // minKey adlı bir değişken tanımla ve değerini int.MaxValue olarak ayarla
            int minIndex = -1; // minIndex adlı bir değişken tanımla ve değerini -1 olarak ayarla

            for (int j = 0; j < graph.GetLength(0); j++) // graph dizisinin boyutu kadar döngü
            {
                if (!mstSet[j] && key[j] < minKey) // eğer mstSet dizisinin j. indisli değeri false ise ve key dizisinin j. indisli değeri minKey değerinden küçükse
                {
                    minKey = key[j]; // minKey değerini key dizisinin j. indisli değerine eşitler
                    minIndex = j; // minIndex değerini j değerine eşitler
                }
            }

            mstSet[minIndex] = true; // mstSet dizisinin minIndex indisli değerini true değerine eşitler
            minCost += key[minIndex]; // minCost değerini key dizisinin minIndex indisli değerine eşitler

            for (int j = 0; j < graph.GetLength(0); j++) // graph dizisinin boyutu kadar döngü
            {
                if (graph[minIndex, j] != 0 && !mstSet[j] && graph[minIndex, j] < key[j]) // eğer graph dizisinin minIndex indisli satırının j. indisli sütunu 0 değil ise, mstSet dizisinin j. indisli değeri false ise ve graph dizisinin minIndex indisli satırının j. indisli sütunu key dizisinin j. indisli değerinden küçükse
                {
                    key[j] = graph[minIndex, j]; // key dizisinin j. indisli değerini graph dizisinin minIndex indisli satırının j. indisli sütununa eşitler
                }
            }
        }

        Console.WriteLine("Minimum çevrimli ağaç:"); // "Minimum çevrimli ağaç:" yazısını konsola ekranına yazdır
        for (int i = 1; i < key.Length; i++) // key dizisinin boyutu kadar döngü, ancak döngü 1. indisten başlasın
        {
            Console.WriteLine($"{i} - {key[i]}"); // key dizisinin i. indisli değerini konsola ekranına yazdır
        }

        Console.WriteLine($"Toplam maliyet: {minCost}"); // "Toplam maliyet: " yazısını ve minCost değerini konsola ekranına yazdır
    }
}
