﻿using System;
using System.Collections.Generic;

class Program
{
    // Bu, programın başlangıç noktası olan ana metod
    static void Main()
    {
        // Grafiği temsil etmek için 2B boyutlu bir dizi tanımla.
        // graph[i, j] değeri, i ve j düğümleri arasındaki kenarın ağırlığını temsil eder.
        int[,] graph = new int[,]
        {
            { 0, 4, 0, 0, 0, 0, 0, 8, 0 },
            { 4, 0, 8, 0, 0, 0, 0, 11, 0 },
            { 0, 8, 0, 7, 0, 4, 0, 0, 2 },
            { 0, 0, 7, 0, 9, 14, 0, 0, 0 },
            { 0, 0, 0, 9, 0, 10, 0, 0, 0 },
            { 0, 0, 4, 14, 10, 0, 2, 0, 0 },
            { 0, 0, 0, 0, 0, 2, 0, 1, 6 },
            { 8, 11, 0, 0, 0, 0, 1, 0, 7 },
            { 0, 0, 2, 0, 0, 0, 6, 7, 0 }
        };

        // Dijkstra algoritması için başlangıç düğümünü tanımla
        int startNode = 0;

        // Dijkstra metodunu çağırın ve startNode'dan diğer tüm düğümlere olan en kısa yolları bulun
        int[] distances = Dijkstra(graph, startNode);

        // En kısa yolları konsola ekranına yazdır
        Console.WriteLine("En kısa yollar:");
        for (int i = 0; i < distances.Length; i++)
        {
            Console.WriteLine($"{startNode} -> {i}: {distances[i]}");
        }
    }

    // Bu metod, Dijkstra algoritmasını kullanarak bir startNode'dan diğer tüm düğümlere olan en kısa yolları bulur
    static int[] Dijkstra(int[,] graph, int startNode)
    {
        // Grafiğin düğüm sayısını al
        int n = graph.GetLength(0);

        // En kısa mesafeyi her düğüme kadar olan bir dizi tanımla
        // İlk olarak, tüm mesafeler en yüksek olabilecek değere ayarlanır, ancak startNode en sıfıra ayarlanır
        int[] distances = new int[n];
        for (int i = 0; i < n; i++)
        {
            distances[i] = int.MaxValue;
        }
        distances[startNode] = 0;

        // Ziyaret edilmiş düğümleri takip etmek için bir bool dizisi tanımla
        bool[] visited = new bool[n];
        for (int i = 0; i < n; i++)
        {
            visited[i] = false;
        }

        // Dijkstra algoritmasının ana döngüsü.
        // Bu döngü, n-1 kez çalıştırılır,
        // burada n, grafiğin düğüm sayısıdır
        for (int i = 0; i < n - 1; i++)
        {
            // En küçük mesafeye sahip ziyaret edilmemiş düğümü bul
            int minDistance = int.MaxValue;
            int currentNode = -1;
            for (int j = 0; j < n; j++)
            {
                if (!visited[j] && distances[j] < minDistance)
                {
                    minDistance = distances[j];
                    currentNode = j;
                }
            }

            // currentNode'u ziyaret edildi olarak işaretle
            visited[currentNode] = true;

            // currentNode'un komşu düğümlerinin mesafelerini güncelle
            for (int j = 0; j < n; j++)
            {
                // currentNode ile j düğümü arasında bir kenar var mı
                if (graph[currentNode, j] != 0 && !visited[j])
                {
                    // Yeni bir mesafe hesapla, currentNode'a olan mesafeyi, currentNode ile j düğümü arasındaki kenarın ağırlığıyla toplayarak
                    int newDistance = distances[currentNode] + graph[currentNode, j];

                    // Yeni mesafe, j düğümüne olan şu anki mesafeden küçük mü diye kontrol et
                    // Eğer küçükse, j düğümüne olan mesafeyi yeni mesafeyle güncelle
                    if (newDistance < distances[j])
                    {
                        distances[j] = newDistance;
                    }
                }
            }
        }
        // En kısa mesafeler dizisini döndür
        return distances;
    }
}
